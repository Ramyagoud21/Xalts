import Locators from '../support/Locators.js'
class Login {
    LoginAsUser() {
        cy.visit("https://xaltsocnportal.web.app/")
    }
    SignIn() {
        cy.contains('Sign In').click();
    }
    SignUp() {
        cy.fixture('hello').then((Data) => {
            cy.get(Locators.email).type(Data.email);
            cy.get(Locators.password).type(Data.password).click();
            cy.get(Locators.confirmPassword).type(Data.confirmPassword).click();
            cy.contains('Sign Up').click();
        })
    }
    NormalSignIn() {
        cy.fixture('hello').then((Data) => {
            cy.contains('Already have an account? Click here to sign in.').click();
            cy.get(Locators.email).type(Data.email);
            cy.get(Locators.password).type(Data.password).click();
            cy.contains('Sign In').click();
        })

    }
    SignOut() {
        cy.contains('Sign Out').click();
    }
}
export default Login;