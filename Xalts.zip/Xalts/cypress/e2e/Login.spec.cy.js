///<reference types="cypress" />
import Login from "./Login.js";
describe('SignIn to Xalts Application', () => {
  const xl = new Login();
  it('Naviagate to the Xalts URL', () => {
    xl.LoginAsUser();
  })
  it('User SignUp after entering all feilds', () => {
    xl.LoginAsUser();
    xl.SignIn();
    xl.SignUp();
  })
  it('User should be able to click on the SignIn', () => {
    xl.LoginAsUser();
    xl.SignIn();
    xl.NormalSignIn();
  })
  it('User should be able to click on the SignOut', () => {
    xl.LoginAsUser();
    xl.SignIn();
    xl.NormalSignIn();
    cy.wait(2000);
    xl.SignOut();
  })

})

