export default
    {
        email: "#root > div > main > div:nth-child(2) > div:nth-child(2)",
        password: "#root > div > main > div:nth-child(2) > div:nth-child(4) > div",
        confirmPassword: "#root > div > main > div:nth-child(2) > div:nth-child(6) > div",
        SignIn: "#root > div > main > div:nth-child(2) > div:nth-child(8) > button",
    }